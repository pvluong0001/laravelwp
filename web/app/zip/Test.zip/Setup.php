<?php

namespace Modules\Test;

class Setup {
    public function install() {
        add_role('role_from_plugin');
    }

    public function uninstall() {
        remove_role('role_from_plugin');
    }
}
