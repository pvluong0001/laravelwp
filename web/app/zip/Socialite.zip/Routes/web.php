<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::prefix('socialite')->group(function() {
    Route::get('/', 'SocialiteController@index');
});

Route::get('login/github', [\Modules\Socialite\Http\Controllers\SocialiteController::class, 'redirectToProvider']);
Route::get('login/github/callback', [\Modules\Socialite\Http\Controllers\SocialiteController::class, 'handleProviderCallback']);
