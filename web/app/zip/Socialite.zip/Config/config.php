<?php

return [
    'name' => 'Socialite'
];
